#!/usr/bin/env bash
#EXP gpus=1 cpus=8 mem=8G time=01:00:00 part=general
# HYPOTHESIS: none -- owner question 2026-11-13: what uses the space in the whole home and data directories. Read-only du.
export D="/data/user_data/$USER"

phase scan "test -s $AE_RESULTS/du_all.txt" '
    {
      echo "== df"; df -h "$D" "$HOME" 2>&1
      echo "== other mounts writable by user"; for m in /scratch /data/tmp /compute /tmp; do [ -d "$m/$USER" ] && du -sh "$m/$USER" 2>/dev/null; done; echo "(end)"
      echo "== DATA depth 1"; du -h --max-depth=1 "$D" 2>/dev/null | sort -h
      echo "== DATA depth 2 (>=100M)"; du --max-depth=2 -m "$D" 2>/dev/null | awk "\$1>=100" | sort -n
      echo "== DATA depth 3 (>=1G)"; du --max-depth=3 -m "$D" 2>/dev/null | awk "\$1>=1024" | sort -n
      echo "== qis/ckpt depth 2"; du --max-depth=2 -m "$D/qis/ckpt" 2>/dev/null | sort -n | tail -40
      echo "== HOME depth 1 (incl. hidden)"; du -h --max-depth=1 "$HOME" 2>/dev/null | sort -h
      echo "== HOME depth 2 (>=100M)"; du --max-depth=2 -m "$HOME" 2>/dev/null | awk "\$1>=100" | sort -n
      echo "== HOME depth 3 (>=500M)"; du --max-depth=3 -m "$HOME" 2>/dev/null | awk "\$1>=500" | sort -n
      echo "== HOME files >=500M"; find "$HOME" -xdev -type f -size +500M -printf "%s\t%TY-%Tm-%Td\t%p\n" 2>/dev/null | sort -n | tail -40
    } > "$AE_RESULTS/du_all.txt" 2>&1
'
