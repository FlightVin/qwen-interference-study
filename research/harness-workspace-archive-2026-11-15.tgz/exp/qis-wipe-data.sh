#!/usr/bin/env bash
#EXP gpus=1 cpus=16 mem=8G time=01:30:00 part=general
# HYPOTHESIS: none -- owner instruction 2026-11-13: delete /data/user_data/$USER/qis and /data/user_data/$USER/BC2RL
# completely. Nothing else under /data/user_data/$USER is touched.
export D="/data/user_data/$USER"

phase before "test -s $AE_RESULTS/before.txt" '
    case "$D" in /data/user_data/?*) ;; *) echo "unexpected D=$D"; exit 1;; esac
    { df -h "$D"; ls -la "$D"; du -sh "$D/qis" "$D/BC2RL" 2>&1; } > "$AE_RESULTS/before.txt"
'
phase delete "test -s $AE_RESULTS/after.txt" '
    for top in qis BC2RL; do
        t="$D/$top"
        [ -d "$t" ] || continue
        # parallel over second-level entries (the large run and checkpoint folders), then the rest
        find "$t" -mindepth 2 -maxdepth 2 -print0 | xargs -0 -r -n 4 -P 16 rm -rf -- || true
        rm -rf -- "$t"
    done
    left=0
    for top in qis BC2RL; do if [ -e "$D/$top" ]; then left=$((left+1)); echo "STILL PRESENT: $D/$top"; fi; done
    { echo "left=$left"; df -h "$D"; ls -la "$D"; du -h --max-depth=1 "$D" 2>/dev/null | sort -h; } > "$AE_RESULTS/after.txt"
    [ "$left" -eq 0 ]
'
