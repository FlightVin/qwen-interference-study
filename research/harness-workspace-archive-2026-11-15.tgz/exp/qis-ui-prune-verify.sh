#!/usr/bin/env bash
#EXP gpus=1 cpus=2 mem=4G time=00:15:00 part=general
# HYPOTHESIS: none -- read-only check after qis-ui-prune (job 11142531), whose verify step failed under pipefail.
export UI="/data/user_data/$USER/qis/ui"

phase verify "test -s $AE_RESULTS/df_after.txt" '
    { echo "model.pt left: $(find "$UI/soup" -type f -name model.pt | wc -l)"
      echo "sk_*.npy left: $(find "$UI" -type f -name "sk_*.npy" | wc -l)"
      df -h "$UI"; du -sh "$UI"; du -h --max-depth=1 "$UI" | sort -h
      echo "files remaining: $(find "$UI" -type f | wc -l)"
      echo "first-study ckpt: $(du -sh /data/user_data/$USER/qis/ckpt | cut -f1)"; } > "$AE_RESULTS/df_after.txt" 2>&1
'
