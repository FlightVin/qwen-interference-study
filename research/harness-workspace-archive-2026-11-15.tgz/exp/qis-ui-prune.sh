#!/usr/bin/env bash
#EXP gpus=1 cpus=8 mem=8G time=00:30:00 part=general
# HYPOTHESIS: none -- owner instruction 2026-11-13: delete the rebuildable large files of study Nov-12-2026-01.
# Scope: $PROJ_DATA/ui/soup/*/model.pt and every sk_*.npy under $PROJ_DATA/ui. Nothing else. Samples, summaries,
# gram files and the first study's folders stay.
export UI="/data/user_data/$USER/qis/ui"

phase manifest "test -s $AE_RESULTS/manifest.tsv" '
    case "$UI" in /data/user_data/*/qis/ui) ;; *) echo "unexpected UI=$UI"; exit 1;; esac
    test -d "$UI" || { echo "no $UI"; exit 1; }
    df -h "$UI" > "$AE_RESULTS/df_before.txt"; du -sh "$UI" >> "$AE_RESULTS/df_before.txt"
    { find "$UI/soup" -mindepth 2 -maxdepth 2 -type f -name model.pt -printf "%s\t%p\n"
      find "$UI" -type f -name "sk_*.npy" -printf "%s\t%p\n"; } > "$AE_RESULTS/manifest.tmp"
    if grep -v -P "^\d+\t/data/user_data/[^/]+/qis/ui/" "$AE_RESULTS/manifest.tmp"; then echo "path outside ui"; exit 1; fi
    mv "$AE_RESULTS/manifest.tmp" "$AE_RESULTS/manifest.tsv"
    awk -F"\t" "{s+=\$1} END{printf \"files %d, apparent GB %.1f\n\", NR, s/1e9}" "$AE_RESULTS/manifest.tsv" | tee "$AE_RESULTS/manifest_total.txt"
'
phase delete "test -s $AE_RESULTS/df_after.txt" '
    cut -f2 "$AE_RESULTS/manifest.tsv" | tr "\n" "\0" | xargs -0 -r -n 1 -P 8 rm -f --
    left=$(cut -f2 "$AE_RESULTS/manifest.tsv" | while read -r p; do [ -e "$p" ] && echo "$p"; done | wc -l)
    echo "files left from manifest: $left" | tee "$AE_RESULTS/left.txt"
    [ "$left" -eq 0 ] || exit 1
    { df -h "$UI"; du -sh "$UI"; du -h --max-depth=1 "$UI" | sort -h; echo "files remaining: $(find "$UI" -type f | wc -l)"; } > "$AE_RESULTS/df_after.txt"
'
