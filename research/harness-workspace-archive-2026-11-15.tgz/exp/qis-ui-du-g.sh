#!/usr/bin/env bash
#EXP gpus=1 cpus=2 mem=8G time=00:40:00 part=general
# HYPOTHESIS: none -- owner question 2026-11-13: disk space used by study Nov-12-2026-01 on Babel. Read-only du/ls.
export PROJ_DATA="/data/user_data/$USER/qis"
export AEROOT="$HOME/ae-qis"

phase scan "test -s $AE_RESULTS/du.txt" '
    {
      echo "== df"; df -h /data/user_data/$USER $HOME 2>&1
      echo "== PROJ_DATA top (du -sh, mtime)"; for d in "$PROJ_DATA"/*; do printf "%s\t%s\t%s\n" "$(du -sh "$d" 2>/dev/null | cut -f1)" "$(date -r "$d" +%F_%H:%M)" "$d"; done
      echo "== ui depth 1"; du -h --max-depth=1 "$PROJ_DATA/ui" 2>&1 | sort -h
      echo "== ui depth 2"; du -h --max-depth=2 "$PROJ_DATA/ui" 2>&1 | sort -h | tail -70
      echo "== ui file count"; find "$PROJ_DATA/ui" -type f | wc -l
      echo "== ui largest files"; find "$PROJ_DATA/ui" -type f -size +200M -printf "%s\t%TY-%Tm-%Td\t%p\n" | sort -n | tail -60
      echo "== hf hub"; du -sh "$PROJ_DATA"/hf/hub/* 2>&1; ls -la --time-style=long-iso "$PROJ_DATA/hf/hub" 2>&1
      echo "== files outside ui changed since 2026-11-12 (dirs, GB)"; find "$PROJ_DATA" -path "$PROJ_DATA/ui" -prune -o -type f -newermt "2026-11-12 00:00" -printf "%s\t%h\n" 2>/dev/null | awk -F"\t" "{a[\$2]+=\$1} END{for(k in a) printf \"%.3f GB\t%s\n\", a[k]/1e9, k}" | sort -n | tail -40
      echo "== home: ae root"; du -h --max-depth=1 "$AEROOT" 2>&1 | sort -h
      echo "== home: ae root, changed since 2026-11-12, per top dir"; for d in "$AEROOT"/*; do printf "%s\t%s\n" "$(find "$d" -type f -newermt "2026-11-12 00:00" -printf "%s\n" 2>/dev/null | awk "{s+=\$1} END{printf \"%.3f GB\", s/1e9}")" "$d"; done
      echo "== home: results-large"; du -sh "$AEROOT/results-large" 2>&1; ls -la "$AEROOT/results-large" 2>&1 | head -20
      echo "== home: code worktrees"; ls -la --time-style=long-iso "$AEROOT/code" 2>&1 | tail -40; du -sh "$AEROOT/code" 2>&1
      echo "== home: repo clone"; du -sh "$HOME/projects/qwen-interference-study" 2>&1
      echo "== home: caches touched since 2026-11-12"; du -sh "$HOME/.cache" 2>&1; find "$HOME/.cache" -type f -newermt "2026-11-12 00:00" -printf "%s\n" 2>/dev/null | awk "{s+=\$1} END{printf \"%.3f GB new\n\", s/1e9}"
    } > "$AE_RESULTS/du.txt" 2>&1
'
