# PROJECT (harness pointer)

**Active study:** `Nov-12-2026-01-vineeth-babel-slurm-understanding-interference`. Its instruction (`project.md`) is
`../agent-project-instructions-archive/Nov-12-2026-01-vineeth-babel-slurm-understanding-interference/project-instructions.md` (tracked). This file holds no protocol.
Owner amendments are recorded at the end of this file and in that document. The first study's instruction is
`../agent-project-instructions-archive/Nov-12-2026-00-vineeth-babel-slurm-initial-study/project-instructions.md`.

## Operational paths
| item | value |
|---|---|
| project repo / branch | `../` (`FlightVin/qwen-interference-study`), `main` |
| Babel clone | `~/projects/qwen-interference-study` |
| harness root on Babel | `~/ae-qis` |
| `PROJ_DATA` | `/data/user_data/$USER/qis` (env, hf cache, data, runs, ckpt, records) |
| environment | `$PROJ_DATA/env/venv-v1` (uv, Python 3.12, verl 0.9.0) |
| expid prefix / tinker prefix / standbys | `qis-` / `qis-inv` / `qis-dbg*` |
| submission | `ops/qis-submit <expid>` (slot guard: 2 general, 6 preempt, 30 CPUs) |
| outputs of the active study on Babel | `$PROJ_DATA/ui/`; expids `qis-ui-*` |
| tracked research records | `../research/`, run registry `../registry/runs.jsonl` |
| W&B project | `qis-qwen-interference` (unique prefix) |

## Writing standard (owner's words)
See `agent.md` "Writing standard"; it applies to every document of this project.

## Owner amendments
### 2026-11-07 (session start, owner message)
Full autonomy within `project.md` scope. Ceilings: 2 general GPUs and 6 preempt GPUs across all
project activity. Control only jobs verified against this project's ledger and exact job ID; leave
other projects' jobs, processes, files, environments and W&B runs untouched. Cancel owned jobs only
when duplicated, wrong data/config, invalid reward/loss, or demonstrably stalled (not for a weak
curve). Preserve logs/cost/checkpoints when moving or replacing; give replacements traceable attempt
IDs. On W&B failure switch to offline/local JSONL and continue. Record consequential decisions with
evidence, action, affected runs, interpretation impact. Keep failed attempts in the ledger and charge
their compute. Start and test the hourly review and watcher before long waits. Ask the owner only
for credentials, more resources, or a change to the research question or frozen design.
### 2026-11-07 (owner message) — CPU allowance
Up to 30 CPUs on `preempt_cpu_qos` for this project (root `project.md` §17, DECISIONS D20).
### 2026-11-12 (owner message) — new study `Nov-12-2026-01-vineeth-babel-slurm-understanding-interference`
Research and theory on why the first study saw no interference. No training runs; propose them. Measurements on stored
checkpoints are allowed. Compute budget: 2 general GPUs and 6 preempt GPUs. All outputs in `reports/Nov-12-2026-01-vineeth-babel-slurm-understanding-interference/`.
Deliverables: `00-initial-theory.md`, `01-understanding.md`, updated README files. Full text: the study's
`project-instructions.md` §1. This supersedes the 8-general-GPU allowance of amendments A20-A27 of the first study.
### 2026-11-12 (owner message) — general GPU ceiling raised
> You may use all 8 general GPUs for the time-being until I instruct otherwise.

Ceiling: 8 general GPUs (the account limit), until the owner says otherwise. The preempt ceiling stays at 6. This
supersedes the 2-general-GPU ceiling of the mandate for now.
### 2026-11-12 (owner message) — scale gradient runs removed from scope
> Please remove gradient geometry on 0.6B and 4B from your scope of experiments and leave them as future work.

Jobs 11131757 (`qis-ui-geom-q06x64`) and 11131734 (`qis-ui-geom-q4x64`) were cancelled while pending. They are future
work in `01-understanding.md`, Section 3, M1.

### 2026-11-12 (owner message, about 23:00 EST) — remove the 0.6B run; synopses; capacity; domain study; summary
> > The finished 16-answer run on Qwen3-0.6B stays in Section 1.7, marked underpowered. Tell me if you want that removed as well.
>
> Yes, please remove it.
>
> After the last stage in
> > Dev accuracy of the last three averaged checkpoints
>
> which appears to be the last task, finalize 01-understanding.md. Also write versions of 00-initial-theory.md and 01-understanding.md as 02 and 03 that can be skimmed through and parsed with 10-15 minutes (each). These new documents must serve as complete synopses of the more verbose documents, and must convey key information succintly with apt use of images and plots.
>
> Secondly, the question of "capacity" is curious, and you should propose or run a few experiments on the existing checkpoints that tell us something about this. Please review adjacent literature before doing so, and only finalize 01-understanding.md once this is completed and included. Please do not run spurious experiments just for the sake of running them, and exercise judgement as a vetted research scientist. Stating that such "capacity" experiments only make sense when we have trained with additional sizes, and instead proposing future experiments is also valid.
>
> Lastly, as an additional study, since we haven't achieved the pre-conditions for ray interference - i.e., negative coupling and near zero success rates on hard problems - it is of vital importance that we are able to curate domain mixtures that demonstrate this behavior for qwen-1.7B. You are tasked with finding such domains and dataset mixtures that allow interference to happen along different axes including (1) scale of interference (no interference, some interference, great interference), (2) hardness of tasks (some initial success, marginal initial success, no initial success), (3) other important axes for an empirical study of what does pre-training and model scale induce to cause many domains (hypotheses) to not have significant ray interference on a broad range of tasks.
>
> This new study will go within 04-domains-to-explore.md which should be short and succint document listing key information points such as existing performance and dataset names / links, etc. (you are to deem what "key" information constitutes) that we can use as reference for further evaluations.
>
> Finally end with a 05-summary.md that can be scanned wthin 10 minutes for broader direction and understanding, as well as synopses of all the previous markdown files.

Deliverables added, all in `reports/<ID>/`: `02-*` (synopsis of `00-initial-theory.md`), `03-*` (synopsis of
`01-understanding.md`), `04-domains-to-explore.md`, `05-summary.md`. `01-understanding.md` is final only after the
averaged-checkpoint accuracy and the capacity work are included. The 16-answer Qwen3-0.6B run leaves the report.

### Owner amendment, 2026-11-13 (storage and records)
- The owner ordered the deletion of all project storage on Babel: `/data/user_data/$USER/qis`, `/data/user_data/$USER/BC2RL`,
  `~/ae-qis`, `~/projects/qwen-interference-study`, `~/ae-bc2rl`, `~/projects/BC2RL`, `~/.cache/vllm`. Done on 2026-11-13.
  "any subsequent study will use a clean state".
- The owner ordered `state/FINDINGS.md` and `state/LEDGER.jsonl` cleared, with this rule: future runs use the
  `research/` directory in the repository for their records, not this harness folder.
