# FINDINGS — append-only durable results

> **Owner instruction, 2026-11-13.** The owner cleared this file and `state/LEDGER.jsonl` on this date, after all
> Babel storage of the project was deleted. Future runs must keep their durable records in the repository, under
> `research/<study-ID>/` (findings, decisions, job tables, recipes, handover), not in this harness folder.
> `ae harvest` and `ae submit` still append their mechanical lines here and to the ledger; treat those as scratch.
> Copy every durable conclusion and every job record (expid, job ID, commit, state) to `research/<study-ID>/`.
> Earlier findings are in `reports/` and `research/` of the repository.

<!-- `ae harvest` appends one line per harvested experiment. -->
