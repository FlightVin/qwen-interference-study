# CHECKLIST (harness pointer)
The live plan is `../research/Nov-12-2026-01-vineeth-babel-slurm-understanding-interference/CHECKLIST.md`. Section 0 there holds the owner's non-negotiable rules.
