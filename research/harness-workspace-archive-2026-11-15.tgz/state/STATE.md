# STATE (harness pointer)
Active study: `Nov-12-2026-01-vineeth-babel-slurm-understanding-interference`.
Its state is `../research/Nov-12-2026-01-vineeth-babel-slurm-understanding-interference/STATE.md`. Read it first.
The first study (`Nov-12-2026-00-vineeth-babel-slurm-initial-study`) is finished and its records are FROZEN (owner instruction A30,
2026-11-12); its handover is `../research/Nov-12-2026-00-vineeth-babel-slurm-initial-study/HANDOVER.md`.
Instructions archive: `../agent-project-instructions-archive/`. Submissions on Babel: `../ops/qis-submit`.
